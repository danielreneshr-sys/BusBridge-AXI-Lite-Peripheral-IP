`timescale 1ns/1ps
module busbridge_axi_lite #(
    parameter ADDR_WIDTH = 4,
    parameter DATA_WIDTH = 32
)(
    input  wire                     aclk,
    input  wire                     aresetn,

    input  wire [ADDR_WIDTH-1:0]    s_axi_awaddr,
    input  wire                     s_axi_awvalid,
    output wire                     s_axi_awready,

    input  wire [DATA_WIDTH-1:0]    s_axi_wdata,
    input  wire [DATA_WIDTH/8-1:0]  s_axi_wstrb,
    input  wire                     s_axi_wvalid,
    output wire                     s_axi_wready,

    output wire [1:0]               s_axi_bresp,
    output wire                     s_axi_bvalid,
    input  wire                     s_axi_bready,

    input  wire [ADDR_WIDTH-1:0]    s_axi_araddr,
    input  wire                     s_axi_arvalid,
    output wire                     s_axi_arready,

    output wire [DATA_WIDTH-1:0]    s_axi_rdata,
    output wire [1:0]               s_axi_rresp,
    output wire                     s_axi_rvalid,
    input  wire                     s_axi_rready,

    output wire                     irq
);

    reg [DATA_WIDTH-1:0] reg0_control;
    reg [DATA_WIDTH-1:0] reg1_status;
    reg [DATA_WIDTH-1:0] reg2_data;
    reg [DATA_WIDTH-1:0] reg3_event_count;

    reg aw_hold, w_hold, bvalid_r, ar_hold, rvalid_r;
    reg [ADDR_WIDTH-1:0] awaddr_r, araddr_r;
    reg [DATA_WIDTH-1:0] wdata_r;
    reg [DATA_WIDTH/8-1:0] wstrb_r;
    reg [DATA_WIDTH-1:0] rdata_r;

    wire do_write = aw_hold && w_hold && !bvalid_r;
    wire do_read  = ar_hold && !rvalid_r;

    assign s_axi_awready = !aw_hold && !bvalid_r;
    assign s_axi_wready  = !w_hold  && !bvalid_r;
    assign s_axi_bvalid  = bvalid_r;
    assign s_axi_bresp   = 2'b00; // OKAY

    assign s_axi_arready = !ar_hold && !rvalid_r;
    assign s_axi_rvalid  = rvalid_r;
    assign s_axi_rdata   = rdata_r;
    assign s_axi_rresp   = 2'b00; // OKAY

    assign irq = reg0_control[1] && reg1_status[0];

    integer i;
    always @(posedge aclk) begin
        if (!aresetn) begin
            reg0_control    <= 32'h0;
            reg1_status     <= 32'h0;
            reg2_data       <= 32'h0;
            reg3_event_count<= 32'h0;
            aw_hold         <= 1'b0;
            w_hold          <= 1'b0;
            bvalid_r        <= 1'b0;
            ar_hold         <= 1'b0;
            rvalid_r        <= 1'b0;
            awaddr_r        <= '0;
            wdata_r         <= '0;
            wstrb_r         <= '0;
            araddr_r        <= '0;
            rdata_r         <= '0;
        end else begin
            if (s_axi_awvalid && s_axi_awready) begin
                aw_hold  <= 1'b1;
                awaddr_r <= s_axi_awaddr;
            end
            if (s_axi_wvalid && s_axi_wready) begin
                w_hold  <= 1'b1;
                wdata_r  <= s_axi_wdata;
                wstrb_r  <= s_axi_wstrb;
            end

            if (do_write) begin
                case (awaddr_r[3:2])
                    2'd0: for (i=0;i<DATA_WIDTH/8;i=i+1)
                              if (wstrb_r[i]) reg0_control[i*8 +: 8] <= wdata_r[i*8 +: 8];
                    2'd1: begin
                        if (wdata_r[0]) reg1_status[0] <= 1'b0; // W1C event flag
                    end
                    2'd2: for (i=0;i<DATA_WIDTH/8;i=i+1)
                              if (wstrb_r[i]) reg2_data[i*8 +: 8] <= wdata_r[i*8 +: 8];
                    2'd3: reg3_event_count <= 32'h0;
                endcase
                aw_hold  <= 1'b0;
                w_hold   <= 1'b0;
                bvalid_r <= 1'b1;
            end

            if (bvalid_r && s_axi_bready)
                bvalid_r <= 1'b0;

            if (s_axi_arvalid && s_axi_arready) begin
                ar_hold  <= 1'b1;
                araddr_r <= s_axi_araddr;
            end

            if (do_read) begin
                case (araddr_r[3:2])
                    2'd0: rdata_r <= reg0_control;
                    2'd1: rdata_r <= reg1_status;
                    2'd2: rdata_r <= reg2_data;
                    2'd3: rdata_r <= reg3_event_count;
                endcase
                ar_hold   <= 1'b0;
                rvalid_r  <= 1'b1;
            end

            if (rvalid_r && s_axi_rready)
                rvalid_r <= 1'b0;

            // Simple internal event generator for demonstration.
            if (reg0_control[0]) begin
                reg3_event_count <= reg3_event_count + 1'b1;
                reg1_status[0]   <= 1'b1;
            end
        end
    end
endmodule
