BusBridge - AXI4-Lite Peripheral IP Development

Submission package contains:
1. PPT presentation
2. PDF project report
3. AXI4-Lite RTL source code
4. Verification testbench
5. Vivado project creation Tcl script

Note: A real public/live project link is not included because it must be created by the student on a hosting service such as GitHub.
