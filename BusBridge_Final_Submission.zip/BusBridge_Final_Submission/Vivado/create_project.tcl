# Vivado 2025.x Tcl script
create_project BusBridge_AXILite ./BusBridge_AXILite -part xc7a35tcpg236-1
add_files ./src/busbridge_axi_lite.v
add_files -fileset sim_1 ./tb/tb_busbridge_axi_lite.v
set_property top tb_busbridge_axi_lite [get_filesets sim_1]
update_compile_order -fileset sources_1
update_compile_order -fileset sim_1
launch_simulation
