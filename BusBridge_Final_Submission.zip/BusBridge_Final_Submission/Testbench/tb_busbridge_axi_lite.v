`timescale 1ns/1ps
module tb_busbridge_axi_lite;
    reg aclk=0, aresetn=0;
    always #5 aclk = ~aclk;

    reg [3:0] awaddr; reg awvalid; wire awready;
    reg [31:0] wdata; reg [3:0] wstrb; reg wvalid; wire wready;
    wire [1:0] bresp; wire bvalid; reg bready=1;
    reg [3:0] araddr; reg arvalid; wire arready;
    wire [31:0] rdata; wire [1:0] rresp; wire rvalid; reg rready=1;
    wire irq;

    busbridge_axi_lite dut(.*);

    task axi_write(input [3:0] addr, input [31:0] data);
      begin
        @(posedge aclk); awaddr<=addr; awvalid<=1; wdata<=data; wstrb<=4'hF; wvalid<=1;
        wait(awready && wready); @(posedge aclk); awvalid<=0; wvalid<=0;
        wait(bvalid); @(posedge aclk);
      end
    endtask

    task axi_read(input [3:0] addr, output [31:0] data);
      begin
        @(posedge aclk); araddr<=addr; arvalid<=1;
        wait(arready); @(posedge aclk); arvalid<=0;
        wait(rvalid); data=rdata; @(posedge aclk);
      end
    endtask

    reg [31:0] rd;
    initial begin
      awaddr=0; awvalid=0; wdata=0; wstrb=0; wvalid=0; araddr=0; arvalid=0;
      repeat(4) @(posedge aclk); aresetn=1;
      $display("TEST 1: write/read DATA register");
      axi_write(4'h8, 32'h1234ABCD);
      axi_read(4'h8, rd);
      if (rd !== 32'h1234ABCD) $fatal("DATA mismatch: %h", rd);

      $display("TEST 2: enable event generator + interrupt");
      axi_write(4'h0, 32'h00000003); // enable + irq enable
      repeat(5) @(posedge aclk);
      axi_read(4'hC, rd);
      if (rd == 0) $fatal("Event counter did not increment");
      if (!irq) $fatal("IRQ did not assert");

      $display("TEST 3: clear status flag");
      axi_write(4'h4, 32'h1);
      axi_read(4'h4, rd);
      if (rd[0] !== 1'b0) $fatal("Status flag did not clear");

      $display("PASS: AXI-Lite BusBridge verification completed.");
      $finish;
    end
endmodule
